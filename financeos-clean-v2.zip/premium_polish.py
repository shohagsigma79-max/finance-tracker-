from pathlib import Path

app = Path('/home/ubuntu/financeos/client/src/App.tsx')
s = app.read_text()
needle = 'function FinanceApp() { const [location] = useLocation();'
injection = '''let financeAudioContext: AudioContext | null = null;

function playButtonSound() {
  try {
    const AudioCtor = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtor) return;
    financeAudioContext ??= new AudioCtor();
    if (financeAudioContext.state === "suspended") void financeAudioContext.resume();
    const now = financeAudioContext.currentTime;
    const oscillator = financeAudioContext.createOscillator();
    const gain = financeAudioContext.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(520, now);
    oscillator.frequency.exponentialRampToValueAtTime(760, now + 0.045);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.032, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.075);
    oscillator.connect(gain);
    gain.connect(financeAudioContext.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.08);
  } catch {
    // Audio is an enhancement; interaction remains fully functional if unavailable.
  }
}

'''
if 'function playButtonSound()' not in s:
    s = s.replace(needle, injection + needle)
old = 'function FinanceApp() { const [location] = useLocation(); const [transactions,setTransactions]'
new = 'function FinanceApp() { const [location] = useLocation(); useEffect(() => { const handleButtonClick = (event: MouseEvent) => { const target = event.target as HTMLElement | null; const button = target?.closest("button"); if (button && !button.disabled) playButtonSound(); }; document.addEventListener("click", handleButtonClick, { passive: true }); return () => document.removeEventListener("click", handleButtonClick); }, []); const [transactions,setTransactions]'
if old in s:
    s = s.replace(old, new)
else:
    raise SystemExit('FinanceApp insertion point not found')
app.write_text(s)

css = Path('/home/ubuntu/financeos/client/src/index.css')
css.write_text(css.read_text() + r'''

/* Soho editorial polish: warm ivory, graphite, violet ink and soft mint. */
:root {
  --soho-ink: #171b25;
  --soho-violet: #5b52f2;
  --soho-mint: #8ee5c0;
  --soho-ivory: #f7f8fa;
  --soho-copper: #e2a36a;
}

body {
  background-color: var(--soho-ivory);
  background-image:
    radial-gradient(circle at 88% 0%, rgba(220, 217, 255, .5), transparent 28rem),
    radial-gradient(circle at 0% 100%, rgba(216, 245, 231, .42), transparent 25rem),
    linear-gradient(115deg, rgba(255,255,255,.25), transparent 42%);
  letter-spacing: -0.005em;
}

body::before {
  content: "";
  pointer-events: none;
  position: fixed;
  inset: 0;
  z-index: 100;
  opacity: .035;
  mix-blend-mode: multiply;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 160 160' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.82' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.65'/%3E%3C/svg%3E");
}

h1, h2, h3, h4, button, nav { font-family: "DM Sans", Inter, ui-sans-serif, system-ui, sans-serif; }
h1, h2, h3, h4 { letter-spacing: -0.045em; }
button { letter-spacing: -0.01em; }

/* Give cards a tactile paper edge without turning the UI glossy. */
main section {
  background-image: linear-gradient(145deg, rgba(255,255,255,.64), rgba(255,255,255,0));
}

button:not(:disabled) { will-change: transform, box-shadow; }
button:not(:disabled):hover { filter: saturate(1.06); }

.dark body {
  background-image:
    radial-gradient(circle at 88% 0%, rgba(91,82,242,.14), transparent 28rem),
    radial-gradient(circle at 0% 100%, rgba(43,154,123,.10), transparent 25rem);
}
.dark body::before { opacity: .02; mix-blend-mode: screen; }
.dark main section { background-image: linear-gradient(145deg, rgba(255,255,255,.025), transparent); }

@media (prefers-reduced-motion: no-preference) {
  main > * { animation: soho-rise .42s var(--ease-out) both; }
  @keyframes soho-rise { from { opacity: 0; transform: translateY(7px); } to { opacity: 1; transform: translateY(0); } }
}
''')
'''
Path('/home/ubuntu/financeos/premium_polish.py').unlink(missing_ok=True)
'''
