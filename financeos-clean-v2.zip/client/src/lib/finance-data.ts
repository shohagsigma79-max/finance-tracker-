export type TransactionType = "income" | "expense" | "transfer";

export type Transaction = {
  id: string;
  date: string;
  merchant: string;
  category: string;
  account: string;
  amount: number;
  type: TransactionType;
  initials: string;
  color: string;
  note?: string;
};

export type Account = {
  id: string;
  name: string;
  type: string;
  balance: number;
  digits?: string;
  color: string;
  institution: string;
};

export type Budget = {
  id: string;
  category: string;
  limit: number;
  spent: number;
  color: string;
};

export type Goal = {
  id: string;
  name: string;
  target: number;
  current: number;
  deadline: string;
  color: string;
  icon: string;
};

export type Bill = {
  id: string;
  name: string;
  amount: number;
  due: string;
  category: string;
  frequency: string;
  status: "upcoming" | "due" | "overdue" | "paid";
};

export type Subscription = {
  id: string;
  name: string;
  amount: number;
  cycle: string;
  next: string;
  category: string;
  active: boolean;
  color: string;
};

export type Debt = {
  id: string;
  name: string;
  original: number;
  remaining: number;
  rate: number;
  minPayment: number;
  due: string;
  color: string;
};

export const categories = ["Food", "Shopping", "Transport", "Housing", "Bills", "Entertainment", "Education", "Health", "Other"];

export const seedTransactions: Transaction[] = [
  { id: "t1", date: "2026-09-10", merchant: "Northstar Studio", category: "Income", account: "Everyday Checking", amount: 6420, type: "income", initials: "NS", color: "#5b52f2", note: "Monthly salary" },
  { id: "t2", date: "2026-09-09", merchant: "Whole Foods Market", category: "Food", account: "Everyday Checking", amount: 126.84, type: "expense", initials: "WF", color: "#2b9a7b" },
  { id: "t3", date: "2026-09-08", merchant: "Airbnb", category: "Travel", account: "Travel Card", amount: 285, type: "expense", initials: "AB", color: "#ff6b4a" },
  { id: "t4", date: "2026-09-07", merchant: "Freelance payment", category: "Income", account: "Everyday Checking", amount: 860, type: "income", initials: "FP", color: "#0f9f8a" },
  { id: "t5", date: "2026-09-06", merchant: "Amazon", category: "Shopping", account: "Travel Card", amount: 74.99, type: "expense", initials: "AM", color: "#f59e0b" },
  { id: "t6", date: "2026-09-05", merchant: "Cedar & Stone", category: "Food", account: "Everyday Checking", amount: 58.2, type: "expense", initials: "CS", color: "#c97a4a" },
  { id: "t7", date: "2026-09-04", merchant: "Metro Transit", category: "Transport", account: "Everyday Checking", amount: 32.5, type: "expense", initials: "MT", color: "#3478c9" },
  { id: "t8", date: "2026-09-03", merchant: "Electricity Co.", category: "Bills", account: "Everyday Checking", amount: 112.47, type: "expense", initials: "EC", color: "#d26b3d" },
  { id: "t9", date: "2026-09-02", merchant: "Horizon Transfer", category: "Transfer", account: "High-yield Savings", amount: 750, type: "transfer", initials: "HT", color: "#786fd8" },
  { id: "t10", date: "2026-09-01", merchant: "Netflix", category: "Entertainment", account: "Travel Card", amount: 22.99, type: "expense", initials: "NF", color: "#ef4444" },
  { id: "t11", date: "2026-08-29", merchant: "Greenline Pharmacy", category: "Health", account: "Everyday Checking", amount: 48.35, type: "expense", initials: "GP", color: "#50a475" },
  { id: "t12", date: "2026-08-27", merchant: "The Book Nook", category: "Education", account: "Everyday Checking", amount: 42.8, type: "expense", initials: "BN", color: "#8f6fb5" },
];

export const accounts: Account[] = [
  { id: "a1", name: "Everyday Checking", type: "Checking", balance: 7840.5, digits: "2048", color: "#5b52f2", institution: "Mercury Bank" },
  { id: "a2", name: "High-yield Savings", type: "Savings", balance: 4310, digits: "8802", color: "#25a67a", institution: "Mercury Bank" },
  { id: "a3", name: "Travel Card", type: "Credit Card", balance: -1250, digits: "4419", color: "#171b25", institution: "Amex" },
  { id: "a4", name: "Brokerage", type: "Investment", balance: 1940, digits: "7304", color: "#db8e30", institution: "Vanguard" },
];

export const budgets: Budget[] = [
  { id: "b1", category: "Housing", limit: 1800, spent: 1650, color: "#5b52f2" },
  { id: "b2", category: "Food", limit: 600, spent: 418, color: "#2b9a7b" },
  { id: "b3", category: "Shopping", limit: 450, spent: 372, color: "#d98a35" },
  { id: "b4", category: "Transport", limit: 250, spent: 142, color: "#3478c9" },
  { id: "b5", category: "Entertainment", limit: 180, spent: 205, color: "#cf5c69" },
  { id: "b6", category: "Health", limit: 200, spent: 48, color: "#50a475" },
];

export const goals: Goal[] = [
  { id: "g1", name: "Emergency Fund", target: 12000, current: 8650, deadline: "Dec 2026", color: "#5b52f2", icon: "shield" },
  { id: "g2", name: "Japan in spring", target: 4200, current: 2480, deadline: "Mar 2027", color: "#2b9a7b", icon: "plane" },
  { id: "g3", name: "New workstation", target: 2800, current: 1960, deadline: "Nov 2026", color: "#d98a35", icon: "sparkles" },
];

export const bills: Bill[] = [
  { id: "bl1", name: "Apartment rent", amount: 1650, due: "Sep 12", category: "Housing", frequency: "Monthly", status: "upcoming" },
  { id: "bl2", name: "Electricity Co.", amount: 112.47, due: "Sep 14", category: "Utilities", frequency: "Monthly", status: "upcoming" },
  { id: "bl3", name: "Internet", amount: 64, due: "Sep 16", category: "Utilities", frequency: "Monthly", status: "upcoming" },
  { id: "bl4", name: "Health insurance", amount: 185, due: "Sep 05", category: "Insurance", frequency: "Monthly", status: "paid" },
  { id: "bl5", name: "Student loan", amount: 240, due: "Aug 28", category: "Debt", frequency: "Monthly", status: "overdue" },
];

export const subscriptions: Subscription[] = [
  { id: "s1", name: "Netflix", amount: 22.99, cycle: "Monthly", next: "Sep 18", category: "Entertainment", active: true, color: "#e50914" },
  { id: "s2", name: "Figma Professional", amount: 15, cycle: "Monthly", next: "Sep 20", category: "Work", active: true, color: "#a259ff" },
  { id: "s3", name: "Spotify", amount: 11.99, cycle: "Monthly", next: "Sep 22", category: "Entertainment", active: true, color: "#1db954" },
  { id: "s4", name: "Strava", amount: 79.99, cycle: "Yearly", next: "Oct 03", category: "Health", active: true, color: "#f95d2a" },
  { id: "s5", name: "Calm", amount: 69.99, cycle: "Yearly", next: "Nov 11", category: "Health", active: false, color: "#84aef2" },
];

export const debts: Debt[] = [
  { id: "d1", name: "Travel Card", original: 4200, remaining: 1250, rate: 19.99, minPayment: 85, due: "Sep 24", color: "#171b25" },
  { id: "d2", name: "Student loan", original: 18000, remaining: 12480, rate: 4.6, minPayment: 240, due: "Sep 28", color: "#5b52f2" },
];

export const cashFlow = [
  { month: "Apr", income: 5820, expenses: 3340, savings: 2480 },
  { month: "May", income: 6100, expenses: 3720, savings: 2380 },
  { month: "Jun", income: 6240, expenses: 3510, savings: 2730 },
  { month: "Jul", income: 6240, expenses: 3980, savings: 2260 },
  { month: "Aug", income: 6420, expenses: 3870, savings: 2550 },
  { month: "Sep", income: 7280, expenses: 3118, savings: 4162 },
];

export const spendingData = [
  { name: "Housing", value: 1650, color: "#5b52f2" },
  { name: "Food", value: 418, color: "#2b9a7b" },
  { name: "Shopping", value: 372, color: "#d98a35" },
  { name: "Transport", value: 142, color: "#3478c9" },
  { name: "Bills", value: 112, color: "#cf5c69" },
  { name: "Other", value: 324, color: "#a7afbd" },
];

export const formatMoney = (value: number, compact = false) => {
  if (compact && Math.abs(value) >= 1000) return `$${(value / 1000).toFixed(1)}k`;
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(value);
};

export const formatDate = (date: string) => new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(new Date(`${date}T12:00:00`));

export const monthTotal = (items: Transaction[], type: TransactionType) => items.filter((item) => item.type === type).reduce((sum, item) => sum + item.amount, 0);
